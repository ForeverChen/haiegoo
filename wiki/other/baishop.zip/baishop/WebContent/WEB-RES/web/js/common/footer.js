/**
 * footer script
 */
$(document).ready(function(){
	
});