package com.baishop.web.mymall;

import org.springframework.web.servlet.ModelAndView;

import com.baishop.controller.PageBaiController;
import com.baishop.framework.web.HttpServletExtendRequest;
import com.baishop.framework.web.HttpServletExtendResponse;

public class Main extends PageBaiController {

	@Override
	public void execute(HttpServletExtendRequest request,
			HttpServletExtendResponse response, ModelAndView modeview) {
		// TODO Auto-generated method stub

	}

}
